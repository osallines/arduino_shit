from PIL import Image
import random
canvas = Image.new("RGB", (150, 100), (255, 255, 255))
intersections = [(10, 15),(20, 25),(30, 35)]
# Define canvas dimensions
width = 40
height = 55
def draw_horizontal_road(canvas, y, thickness):
  for x in range(width):
      canvas.putpixel((x, y), (0, 0, 0))  # Black for roads
      for i in range(thickness):
          canvas.putpixel((x, y + i), (0, 0, 0))
          canvas.putpixel((x, y - i), (0, 0, 0))

def draw_vertical_road(canvas, x, thickness):
  for y in range(height):
      canvas.putpixel((x, y), (0, 0, 0))
      for i in range(thickness):
          canvas.putpixel((x, y + i), (0, 0, 0))
          canvas.putpixel((x, y - i), (0, 0, 0))
        # Intersections (replace x and y values as needed)
          if True:
           intersections = [(10, 15),(20, 25),(30, 35)]
# Draw horizontal roads
for x, y in intersections:
    draw_horizontal_road(canvas, y, 3)

# Draw vertical roads
for x, y in intersections:
    draw_vertical_road(canvas, x, 3)
building_color = (128, 128, 128)  # Gray for buildings
for x in range(width):
  for y in range(height):
      if not (canvas.getpixel((x, y)) == (0, 0, 0)):  # Check if not road
          canvas.putpixel((x, y), building_color)
for _ in range(5):  # Add some random buildings
  x = random.randint(0, width - 1)
  y = random.randint(0, height - 1)
  size = random.randint(3, 7)
  for i in range(size):
      for j in range(size):
          canvas.putpixel((x + i, y + j), building_color)
canvas.save("city.png")

print("City image created and saved as city.png!")