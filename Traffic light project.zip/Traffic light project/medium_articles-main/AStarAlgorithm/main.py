from graph import Graph, Node
from a_star import AStar

def run(S,Z):
    if S == Z:
       print("error: ","You Can't type the same letter as the nodes for start and end")
       return None
    # Create graph
    graph = Graph()
    # Add vertices
    graph.add_node(Node('A', (7,58)))
    graph.add_node(Node('B', (34,58)))
    graph.add_node(Node('C', (68,58)))
    graph.add_node(Node('D', (7,50)))
    graph.add_node(Node('E', (34,43)))
    graph.add_node(Node('F', (60,41)))
    graph.add_node(Node('G', (68,41)))
    graph.add_node(Node('H', (25,26)))
    graph.add_node(Node('I', (60,23)))
    graph.add_node(Node('J', (60,2)))
    
    # Add edges
    graph.add_edge(1,'A', 'B',27)
    graph.add_edge(1,'B', 'C',34)
    graph.add_edge(3,'A', 'D',8)
    graph.add_edge(1,'E', 'D',34)
    graph.add_edge(3,'D', 'H',42)
    graph.add_edge(1,'F', 'E',28)
    graph.add_edge(1,'G', 'F',8)
    graph.add_edge(3,'G', 'I',26)
    graph.add_edge(3,'H', 'J',53)
    graph.add_edge(1,'F', 'I',18)
    graph.add_edge(3,'J', 'I',21)
    graph.add_edge(3,'J', 'G',87)
    graph.add_edge(3,'H', 'I',38)
    graph.add_edge(1,'H', 'E',26)
    graph.add_edge(1,'E', 'B',15)
    graph.add_edge(3,'C', 'G',17)
   

    # Execute the algorithm
    alg = AStar(graph, S, Z)
    print(alg.search())
    path, path_length = alg.search()
    print(" -> ".join(path))
    print(f"Length of the path: {path_length}")
    return (path,path_length)

path = run('H','J')
print(path)