from Astar_algorithm import Graph, Node, AStar
import socket
def run(S,Z):
    if S == Z:
       print("error: ","You Can't type the same letter as the nodes for start and end")
       return None
    # Create graph
    graph = Graph()
    # Add vertices
    graph.add_node(Node('A', (7,58)))
    graph.add_node(Node('B', (34,58)))
    graph.add_node(Node('C', (68,58)))
    graph.add_node(Node('D', (7,50)))
    graph.add_node(Node('E', (34,43)))
    graph.add_node(Node('F', (60,41)))
    graph.add_node(Node('G', (68,41)))
    graph.add_node(Node('H', (25,26)))
    graph.add_node(Node('I', (60,23)))
    graph.add_node(Node('J', (60,2)))
    
    # Add edges
    graph.add_edge(1,'A', 'B',27)
    graph.add_edge(1,'B', 'C',34)
    graph.add_edge(3,'A', 'D',8)
    graph.add_edge(2,'D', 'E',34)
    graph.add_edge(3,'D', 'H',42)
    graph.add_edge(2,'E', 'F',28)
    graph.add_edge(2,'F', 'G',8)
    graph.add_edge(3,'G', 'I',26)
    graph.add_edge(3,'H', 'J',59)
    graph.add_edge(2,'I', 'F',18)
    graph.add_edge(3,'J', 'I',21)
    graph.add_edge(3,'J', 'G',87)
    graph.add_edge(3,'H', 'I',38)
    graph.add_edge(2,'E', 'H',26)
    graph.add_edge(1,'E', 'B',15)
    graph.add_edge(3,'C', 'G',17)
   

    # Execute the algorithm
    alg = AStar(graph, S, Z)
    path, path_length = alg.search()
    print(" -> ".join(path))
    print(f"Length of the path: {path_length}")
    return path
def what_traffic_to_open(S,Z):
    traffic = ['D','E','G','H','I','J']
    open_these_traffic_lights = []
    path = list(run(S,Z))
    print(path)
    for con in path:
        #print(con)
        if con in traffic: # see what conjunctions are a traffic light
            match con: # see what traffic light is this
                case 'D':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'A':
                            open_these_traffic_lights.append(1)
                        case 'H':
                            open_these_traffic_lights.append(2)
                        case 'E':
                            open_these_traffic_lights.append(3)
                case 'E':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'F':
                            open_these_traffic_lights.append(4)
                        case 'H':
                            open_these_traffic_lights.append(5)
                case 'G':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'C':
                            open_these_traffic_lights.append(6)
                        case 'J':
                            open_these_traffic_lights.append(7)
                        case 'I':
                            open_these_traffic_lights.append(8)
                case 'H':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'I':
                            open_these_traffic_lights.append(9)
                        case 'J':
                            open_these_traffic_lights.append(10)
                        case 'D':
                            open_these_traffic_lights.append(11)
                case 'I':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'F':
                            open_these_traffic_lights.append(12)
                        case 'G':
                            open_these_traffic_lights.append(13)
                        case 'J':
                            open_these_traffic_lights.append(14)
                        case 'H':
                            open_these_traffic_lights.append(15)
                case 'J':
                    index = path.index(con)
                    before_conjustion = path[index - 1]
                    match before_conjustion:
                        case 'I':
                            open_these_traffic_lights.append(16)
                        case 'G':
                            open_these_traffic_lights.append(17)
                        case 'H':
                            open_these_traffic_lights.append(18)
    return open_these_traffic_lights

S = 'F'
Z = 'G'
# Configuration
host = '127.0.0.1'  # Replace with your actual IP
port = 5555

# Create a socket object
peer_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the address and port
peer_socket.bind((host, port))

# Listen for incoming connections
peer_socket.listen(5)

print(f"Peer 1 listening on {host}:{port}")

while True:
        # Accept a connection from a peer
        client_socket, client_address = peer_socket.accept()
        print(f"Connection established with {client_address}")

        # Receive data from the peer
        data = client_socket.recv(1024)  # Adjust buffer size as needed
        print(f"Received data: {data.decode()}")

        # Process the data and send the response
        response_data = run(S,Z)   # Replace with your actual processing logic
        client_socket.send(response_data.encode())

        # Close the connection
        client_socket.close()
        data.decode()
        if 'Close' in data.decode() :
            break

what_traffic_to_open('D','E')