# search
Some random search algorithms
[![Build Status](https://travis-ci.org/XeryusTC/search.svg?branch=master)](https://travis-ci.org/XeryusTC/search)
[![Coverage Status](https://coveralls.io/repos/github/XeryusTC/search/badge.svg?branch=master)](https://coveralls.io/github/XeryusTC/search?branch=master)
