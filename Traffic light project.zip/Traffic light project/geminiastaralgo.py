import heapq

class Node:
  def __init__(self, name, position, neighbors):
    self.name = name
    self.position = position
    self.neighbors = neighbors
    self.g_score = 0  # distance from the start node
    self.f_score = 0  # estimated distance to the goal node

def heuristic(node, goal):
    # Pass goal as a Node object to a_star_search
    # ...
    return abs(node.position[0] - goal.position[0]) + abs(node.position[1] - goal.position[1])


def reconstruct_path(came_from, current):
  path = [current]
  while current in came_from:
    current = came_from[current]
    path.append(current)
  path.reverse()
  return path

def a_star_search(graph, start, goal):
  open_set = []
  heapq.heappush(open_set, (0, start))
  came_from = {}
  g_score = {node: float('inf') for node in graph}
  g_score[start] = 0

  while open_set:
    current_f_score, current = heapq.heappop(open_set)

    if current == goal:
      return reconstruct_path(came_from, current)

    for neighbor in current.neighbors:
      tentative_g_score = g_score[current] + 1  # assuming all edges have weight 1

      if tentative_g_score < g_score[neighbor]:
        came_from[neighbor] = current
        g_score[neighbor] = tentative_g_score
        f_score = tentative_g_score + heuristic(neighbor, goal)
        heapq.heappush(open_set, (f_score, neighbor))

  return None

# Create the graph
graph = {}
graph["A"] = Node("A", (7, 58), ["B", "D"])
graph["B"] = Node("B", (34, 58), ["C"])
graph["C"] = Node("C", (68, 58), ["G"])
graph["D"] = Node("D", (7, 50), ["A", "E", "H"])
graph["E"] = Node("E", (34, 43), ["B", "F"])
graph["F"] = Node("F", (60, 41), ["G", "I"])
graph["G"] = Node("G", (68, 41), ["C", "I", "J"])
graph["H"] = Node("H", (25, 26), ["D", "E", "I", "J"])
graph["I"] = Node("I", (60, 23), ["G", "H", "J"])
graph["J"] = Node("J", (60, 2), ["G", "H", "I"])

# Find the shortest path
start = graph["A"]
goal = graph["J"]
path = a_star_search(graph, start, goal)

# Print the path
if path:
  print("The shortest path from A to J is:", path)
else:
  print("No path found from A to J")
