import socket
s = (socket.socket(socket.AF_INET, socket.SOCK_STREAM))
s.bind(('192.168.1.21',5001))
s.listen(5)

while True:
 conn, address = s.accept()
 print(f"connection f {address} has been established")
 data = conn.recv(1024)
 conn.send()

