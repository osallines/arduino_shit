import numpy as np
from PIL import Image
image = Image.open()

def create_grid(image):
    """Converts an image of a grid to a numpy array.

    Args:
        image: A PIL image object.

    Returns:
        A numpy array representing the grid.
    """

    # Extract grid data from image
    grid_data = []
    for row in image.convert('L').getdata():
        grid_data.append([c // 255 for c in row])

    # Convert grid data to numpy array
    grid = np.array(grid_data)

    return grid


def find_start_end(grid):
    """Finds the starting and ending points in the grid.

    Args:
        grid: A numpy array representing the grid.

    Returns:
        A tuple containing the starting and ending points as (block number, direction).
    """

    start_point = None
    end_point = None

    # Iterate through grid cells
    for row in range(len(grid)):
        for col in range(len(grid[row])):
            cell = grid[row][col]

            # Check if cell is a starting point
            if cell == 1 and "S" in image[row, col]:
                start_point = (row, "S")

            # Check if cell is an ending point
            if cell == 3 and "N" in image[row, col]:
                end_point = (row, "N")

    return start_point, end_point


def explore_grid(grid, start_point, end_point):
    """Explores the grid from the starting point to the ending point.

    Args:
        grid: A numpy array representing the grid.
        start_point: The starting point as (block number, direction).
        end_point: The ending point as (block number, direction).

    Returns:
        A list of intersections passed through as {block number, direction}.
    """

    visited = set()
    path = []

    def explore(row, col, direction):
        # Check if cell is within grid and not visited
        if 0 <= row < len(grid) and 0 <= col < len(grid[row]) and (row, col) not in visited:

            # Mark cell as visited
            visited.add((row, col))

            # Check if cell is the ending point
            if (row, col) == end_point:
                path.append((row, col, direction))
                return True

            # Explore adjacent cells based on direction
            if direction == "N":
                if grid[row - 1][col] != 0 and explore(row - 1, col, direction):
                    path.append((row, col, direction))
                    return True
                elif grid[row][col - 1] != 0 and explore(row, col - 1, "W"):
                    path.append((row, col, direction))
                    return True
                elif grid[row][col + 1] != 0 and explore(row, col + 1, "E"):
                    path.append((row, col, direction))
                    return True

            elif direction == "S":
                if grid[row + 1][col] != 0 and explore(row + 1, col, direction):
                    path.append((row, col, direction))
                    return True
                elif grid[row][col - 1] != 0 and explore(row, col - 1, "W"):
                    path.append((row, col, direction))
                    return True
                elif grid[row][col + 1] != 0 and explore(row, col + 1, "E"):
                    path.append((row, col, direction))
                    return True

            elif direction == "W":
                if grid[row][col - 1] != 0 and explore(row, col - 1, direction):
                    path.append((row, col, direction))
                    return True
                elif grid[row - 1][col] != 0 and explore(row - 1, col, "N"):
                    path.append((row, col, direction))
                    return True
                elif grid[row + 1][col] != 0 and explore(row + 1, col, "S"):
                    path.append((row, col, direction))
                    return True
            elif direction == "E":
                if grid[row][col + 1] != 0 and explore(row, col + 1, direction):
                    path.append((row, col, direction))
                    return True
                elif grid[row - 1][col] != 0 and explore(row - 1, col, "N"):
                    path.append((row, col, direction))
                    return True
                elif grid[row + 1][col] != 0 and explore(row + 1, col, "S"):
                    path.append((row, col, direction))
                    return True

            return False

    # Start exploration from starting point
    explore(start_point[0], start_point[1], start_point[1])

    return path


def format_path(path):
    """Formats the path into a list of intersections with sides.

    Args:
        path: A list of intersections passed through as (block number, direction).

    Returns:
        A list of intersections with sides as {block number, side}.
    """

    intersections = []
    for row, col, direction in path:
        # Determine side based on direction
        if direction == "N":
            side = "S"
        elif direction == "S":
            side = "N"
        elif direction == "W":
            side = "E"
        else:
            side = "W"

        intersections.append({"block": row + 1, "side": side})

    return intersections


def main():
    # Your code to load or create the image of the grid goes here

    grid = create_grid(image)  # Assuming you have image loaded
    start_point, end_point = find_start_end(grid)

    if start_point and end_point:
        path = explore_grid(grid, start_point, end_point)
        formatted_path = format_path(path)

        print("Route:")
        for intersection in formatted_path:
            print(f"- Intersection {intersection['block']}, {intersection['side']}")
    else:
        print("Error: Starting or ending point not found in the grid.")


if __name__ == "__main__":
    main()

