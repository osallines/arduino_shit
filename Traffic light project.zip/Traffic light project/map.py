class map:
    #defined variables:
    Accepted_list = ["1s","1e","2w","2s","2e","3w","3s","3e","4w","4s","5n","5e","5s","6n","6e","6s","6w","7n","7e","7s","7w","8n","8w","8s","9n","9e","10w","10n","10e","11w","11n","11e","12w","12n"]    
    A = [12.5,27.5];B = [27.5,27.5] ;C = [42.5,27.5]; D = [12.5,12.5] ; E = [27.5,12.5] ;F = [42.5,12.5]
    Main_points = [
    [[None],            [10.0,35.0,A,A],    [20.0, 30.0,A,B], [None]           ],#1 N(None) E(10,35) S(5,30) W(None)
    [[None],            [25.0, 35.0,B,B],   [20.0,30.0,A,B],  [15.0,35.0,A,A]    ],#2 N(None) E(25,35) S(20,30) W(15,35)
    [[None],            [40.0, 35.0,C,C],   [35.0, 30.0, B,C],[30.0, 35.0,B,B]   ],#3 N(None) E(40,35) S(35,30) W(30,35)
    [[None],            [None],           [50.0, 30.0, C,C],  [45.0, 35.0,C,C]   ],#4 N(None) E(None) S(50,30) W(45,35)
    [[5.0,25.0,A,A],      [10.0, 20.0, A,F],[5.0,15.0,D,D],     [None]           ],#5 N(5,25) E(10,20) S(5,15) W(None)
    [[20.0, 25.0,A,B],  [25.0,20.0,B,E],  [20.0, 15.0,D,E], [15.0, 20.0, A,F]],#6 N(20,25) E(25,20) S(20,15) W(15,20)
    [[35.0, 25.0, B,C], [40.0, 20.0,C,F], [35.0, 15.0, E,F],[30.0,20.0,B,E]  ],#7 N(35,25) E(40,20) S(35,15) W(30,20)
    [[50.0, 25.0,C,C],   [None],           [50.0, 15.0, F,F],  [45.0, 20.0,C,F] ],#8 N(50,25) E(None) S(50,15) W(45,20)
    [[5.0,10.0,D,D],      [10.0, 5.0, D,D],   [None],           [None]           ],#9 N(5,10) E(10,5) S(None) W(None)
    [[20.0, 10.0,D,E],  [25.0, 5.0,E,E],    [None],           [15.0, 5.0, D,D]   ],#10 N(20,10) E(25,5) S(None) W(15,5)
    [[35.0, 10.0, E,F], [40.0,5.0,F,F],     [None],           [30.0, 5.0,E,E]    ],#11 N(35,10) E(40,5) S(None) W(30,5)
    [[50.0, 10.0, F,F],   [None],           [None],           [45.0,5.0,F,F]     ] #12 N(50,10) E(None) S(None) W(45,5)
    ]
    # get the point name > search for the point
    # get to the nearest intersection
    # Point B - Point A, there will be four cases, (-x,-y) (x,y) (x,-y) (-x,y)
    # Map points
    def __init__(route):
       while True:
            route.__start_input_string = input("enter your starting point (e.g. 1s): ").lower # Inputing a 1 number and 1 letter (string)
            route.__end_input_string = input("Enter your end point (e.g. 1s): ").lower # Inputing a 1 number and 1 letter (string)
            if route.__start_input.lower in map.Accepted_list: # if inputes are equal to the things that was inputed
                break
            else:
                print("please redo it")
                

    def letters_to_place(route):
        route.__block_no = int(route.__start_input_string[0]) # getting the number of the block
        route.__dir_block_letter = route.__start_input_string[1] #int badal string 3shan start point fo2(comment)
        route.__dir_block_no = 0
        match route.__dir_block_letter:
            case 'n':
                route.__dir_block_no = 0
            case 'e':
                route.__dir_block_no = 1
            case 's':
                route.__dir_block_no = 2
            case 'w':
                route.__dir_block_no = 3
        route.__start_input_int = route.Main_points[route.__block_no][route.__dir_block_no][0,1]
        # - - - - - - 
        route.__ = route.__end_input[0]
        route.__dir_block_letter = route.__end_input[1] - 1
        match route.__dir_block_letter:
            case 'n':
                route.__dir_block_no = 0
            case 'e':
                route.__dir_block_no = 1
            case 's':
                route.__dir_block_no = 2
            case 'w':
                route.__dir_block_no = 3
        route.__end_input_int = route.Main_points[route.__block_no][route.__dir_block_letter][0,1]

    def nearest_point(route):
        route.__x_axis_diffrence = route.__end_input_int[0] - route.__start_input_int[0]
        route.__y_axis_diffrence = route.__end_input_int[1] - route.__start_input_int[1]
        if route.__x_axis_diffrence < 0: #if for the y diffrence
            route.start_intersection = route.Main_points[route.__start_input[0]-1][route.__start_input[1]-1][3]
            diff_1 = (route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][2]) - (route.start_intersection)
            diff_2 = (route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][3]) - (route.start_intersection)
            if diff_1 > diff_2:
                route.end_intersection = route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][2] 
            else:
                route.end_intersection = route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][3] 
        else:
            route.start_intersection = route.Main_points[route.__start_input[0]-1][route.__start_input[1]-1][2]
            diff_1 =(route.start_intersection) - (route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][2])
            diff_2 =(route.start_intersection) - (route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][3])
            if diff_1 > diff_2:
                route.end_intersection = route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][2] 
            else:
                route.end_intersection = route.Main_points[route.__end_input[0]-1][route.__end_input[1]-1][3]

    def calculations(route):
        diffrence = route.end_intersection - route.start_intersection
        route.vectors_moved = [0,0]
        route.v = []
        while route.v[-1] != 0:
            route.vectors_moved = 
            route.v.append(route.start_intersection-route.vectors_moved)