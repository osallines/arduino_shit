import math
from math import inf
# source of the edited code is: https://github.com/AndreasSoularidis/medium_articles/blob/main/AStarAlgorithm/graph.py
class Node:
    """ 
        This class used to represent each Vertex in the graph 
        ...
        Attributes
        ----------
        value : str
            Represent the value of the node
        x : int
            Represent the x-coordinate of the node
        y : int
            Represent the y-coordinate of the node
        heuristic_value : int
            Coresponds to the manhattan distance plus the distance from the inital node to the current node. Default value is -1
        distance_from_start
            Corresponds to the distance of the node from the initial node. Defaul value is -1
        neighbors : list
            A list with the nodes the current node is connected
        parent : Node
            Represents the parent-node of the current node. Default value is None

        ...
        Methods
        -------
        has_neighbors(self) -> Boolean
            Check if the current node is connected with other nodes (return True). Otherwise return False
        number_of_neighbors(self) -> int
            Calculate and return the number the of the neighbors 
        add_neighboor(self, neighboor) -> None
            Add a new neighbor in the list of neighbors
        extend_node(self) -> list
            return a list of nodes with which the current node is connected 
        __eq__(self, other) -> Boolean
            Determines if two nodes are equal or not, checking their values
        __str__(self) -> str
            Prints the node data
    """

    def __init__(self, value, cordinates, neighbors=None):
        self.value = value
        self.x = cordinates[0]
        self.y = cordinates[1]
        self.heuristic_value = -1
        self.distance_from_start = inf
        self.neighbors_values = []
        if neighbors is None:
            self.neighbors = []
        else:
            self.neighbors = neighbors
        self.parent = None


    def has_neighbors(self):
        """
            Return True if the current node is connected with at least another node.
            Otherwiese return false
        """
        if len(self.neighbors) == 0:
            return False
        return True


    def number_of_neighbors(self):
        """
            Return the number of nodes with which the current node is connected
        """
        return len(self.neighbors)

    ''' '''
    
    def add_neighboor(self, neighboor,ns):
        """
            Add a new node to the neighboor list. In other words create a new connection between the
            current node and the neighboor
            Paramenters
            ----------
            neighboor : node
                Represent the node with which a new connection is created
        """
        self.neighbors.append(neighboor)
        self.neighbors_values.append((ns,neighboor[1]))
    
    

    def extend_node(self):
        """
            Extends the current node, creating and returning a list with all connected nodes
            Returns
            -------
                List
        """
        children = []
        for child in self.neighbors:
            children.append(child[0])
        return children
    

    def __gt__(self, other):
        """
            Define which node, between current node and other node, has the greater value. 
            First examine the heuristic value. If this value is the same for both nodes 
            the function checks the lexicographic series
            Parameters
            ----------
                other: Node:
                    Represent the other node with which the current node is compared
            Returns
            -------
                Boolean
        """
        if isinstance(other, Node):
            if self.heuristic_value > other.heuristic_value:
                return True
            if self.heuristic_value < other.heuristic_value:
                return False
            return self.value > other.value
            

    def get_neighboor(self, value1 ):
       for i in self.neighbors_values:
          if i[0] == value1.value:
             return i[1]

    def __eq__(self, other):
        """
            Define if current node and other node are equal, checking their values. 
            Parameters
            ----------
                other: Node:
                    Represent the other node with which the current node is compared
            Returns
            -------
                Boolean
        """
        if isinstance(other, Node):
            return self.value == other.value
        return self.value == other


    def __str__(self):
        """
            Define that a node is printed with its value. 
            Returns
            -------
                str
        """
        return self.value
class Graph:
    """ 
        This class used to represent the graph data structure.
        ...
        Attributes
        ----------
        nodes : list
            List with all the nodes of the graph
        ...
        Methods
        -------
        add_node(node, node) -> None
            Add a new node in the list of nodes
        find_node(node, value) -> Node
            Find and return the node of the graph with the given value.   
        add_edge(node, value1, value2, weight=1) -> None
            Add a new edge in the graph
        number_of_nodes(node) -> int
            Calculate and return the number of nodes of the graph
        are_connected(node, node_one, node_two) -> Boolean
            Check if the two given nodes are connected each other
        __str__(node) -> str
            Prints the nodes of the graph
    """
    def __init__(node, nodes=None):
        if nodes is None:
            node.nodes = []
        else:
            node.nodes = nodes


    def add_node(node, node_to_add):
        node.nodes.append(node_to_add)


    def find_node(node, value):
        """
            Return True if the node with the given value exist in the graph. Otherwise it return False
            Parameters
            ----------
                value: str
                    Is the value of the node we want to find
            ...
            Return
            ------
                Node
        """
        for node in node.nodes:
            if node.value == value:
                return node 
        return None


    def add_edge(node,relation_type, value1, value2, weight=1):
        """
            Add a new edge between the two given nodes
            Parameters
            ----------
                relation_type: int
                    1 for value 1 to 2, 2 for value 2 to 1, 3 for both
                value1: str
                    The value of the first node
                value2: str
                    The value of the second node 
                weight:
                    The weight of the edge. Default value 1
            ...
            Return
            ------
                Node
        """
        
        node1 = node.find_node(value1)        
        node2 = node.find_node(value2)
        if relation_type == 1:
            if (node1 is not None) and (node2 is not None):
                node1.add_neighboor((node2, weight),node2.value)
        elif relation_type == 2:
           if (node1 is not None) and (node2 is not None):
            node2.add_neighboor((node1, weight),node1.value)
        elif relation_type == 3:
           if (node1 is not None) and (node2 is not None):
            node1.add_neighboor((node2, weight),node2.value)
            node2.add_neighboor((node1, weight),node1.value)
        else:
            print("Error: One or more nodes were not found")


    def number_of_nodes(node):
        """
            Return the number of nodes of the graph
            ...
            Return
            ------
                int
        """
        return f"The graph has {len(node.nodes)} nodes"


    def are_connected(node, node_one, node_two):
        """
            Return True if the given nodes are connected. Otherwise return False
            ...
            Parameters
            ----------
                node_one: str
                    The value of the first node
                node_two: str
                    The value of the second node
            Return
            ------
                Boolean
        """
        node_one = node.find_node(node_one)
        node_two = node.find_node(node_two)

        for neighboor in node_one.neighbors:
            if neighboor[0].value == node_two.value:
                return True
        return False


    def __str__(node):
        """
            Define the way the nodes of graph will be printed. 
            Return
            ------
                str
        """
        graph = ""
        for node in node.nodes:
            graph += f"{node.__str__()}\n" 
        return graph
  

class AStar:
  """
    This class used to represent the Greedy algorithm
    ...
    Attributes
    ----------
    graph : Graph
      Represent the graph (search space of the problem) 
    start : str
      Represent the starting point 
    target : str
      Represent the destination (target) node
    opened : list
      Represent the list with the available nodes in the search process
    closed : list
      Represent the list with the closed (visited) nodes
    number_of_steps : int
      Keep the number of steps of the algorithm
    ...
    Methods
    -------
    manhattan_distance(self, node1, node2) -> int
      Calculate the manhattan distance between the two given nodes  
    calculate_heuristic_value(self, parent, child, target) -> int
      Calculate the heuristic value of the node (child)
    calculate_distance(self, parent, child) -> int
      Calculate the distance from the initial node to the child node
    insert_to_list(self, list_category, node) -> None
      Insert a new node either ot opened or to closed list according to list_category parameter 
    remove_from_opened(self) -> Node
      Remove from the opened list the node with the smallest heuristic value
    opened_is_empty(self) -> Boolean
      Check if the opened list is empty or not
    get_old_node(self, node_value) -> Node
      Return the node from the opened list in case of a new node with the same value
    calculate_path(self, target_node) -> list
      Calculate and return the path from the stat node to target node
    calculate_cost(self, path) -> int
      Calculate and return the total cost of the path
    search(self)
        Implements the core of algorithm. This method searches, in the search space of the problem, a solution 
    """

  def __init__(self, graph, start_position, target):
    self.graph = graph
    self.start = graph.find_node(start_position)
    self.target = graph.find_node(target)
    self.opened = []
    self.closed = []
    self.number_of_steps = 0


  def manhattan_distance(self, node1, node2):
    """
      Calculate and return the manhattan_distance between the two given nodes
      Parameters
      ----------
      node1 : Node
        Represent the first node 
      node2 : Node
        Represent the second node
      ...
      Return 
      ------
        int
    """
    return round(math.sqrt((abs(node1.x - node2.x))**2 + (abs(node1.y - node2.y))**2))


  def calculate_distance(self, parent, child):
    """
      Calculate and return the distance from the start to child node. If the heuristic value has already calculated
      and is smaller than the new value, the method return theold value. Otherwise the method return the new value
      and note the parent as the parent node of child
      Parameters
      ----------
      parent : Node
        Represent the parent node
      child : Node
        Represent the child node
      ...
      Return 
      ------
        int
    """
    for neighbor in parent.neighbors:
      if neighbor[0] == child:
        distance = parent.distance_from_start + neighbor[1]
        if distance < child.distance_from_start:
          child.parent = parent
          return distance
        
        return child.distance_from_start


  def calculate_heuristic_value(self, parent:Node, child, target):
    """
      Calculate and return the heuristic value of a node which is the sum of the 
      manhattan distance to the target node and the distance from the initial node
      ...
      Parameters
      ----------
        parent : Node
          Represent the selected node
        child : Node
          Represent the child of the selected node
        target : Node
          Represent final state of the problem
      Returns
      -------
        int
    """
    return self.manhattan_distance(child, target) + int(parent.get_neighboor(child))
    
  
  def insert_to_list(self, list_category, node):
    """
      Insert a node in the proper list (opened or closed) according to list_category
      Parameters
      ----------
      list_category : str
          Determines the list in which the node will be appened. If the value is 'open' 
          the node is appended in the opened list. Otherwise, the node is appended in the closed list
      node : Node
          The node of the problem that will be added to the frontier
    """
    if list_category == "open":
      self.opened.append(node)
    else:
      self.closed.append(node)
  

  def remove_from_opened(self):
    """
      Remove the node with the smallest heuristic value from the opened list
      Then add the removed node to the closed list
      Returns
      -------
        Node
    """
    self.opened.sort()
    # for n in self.opened:
    #   print(f"({n},{n.heuristic_value})", end = " ")
    # print("\n")
    node = self.opened.pop(0)
    self.closed.append(node)
    return node


  def opened_is_empty(self):
    """
      Check if the the list opened is empty, so no solution found
      Returns
      -------
      Boolean
        True if the list opened is empty
        False if the list opened is not empty
    """
    return len(self.opened) == 0


  def get_old_node(self, node_value):
    """
      Return the node with the given value from the opened list,
      to compare its heuristic_value with a node with the same value
      ...
      Parameters
      ----------
        node_value : Node
        Represent the value of the node
      Returns
      -------
        Node
    """
    for node in self.opened:
      if node.value == node_value:
        return node
    return None 
      

  def calculate_path(self, target_node):
    """
      Calculate and return the path (solution) of the problem
      ...
      Parameters
      ----------
        target_node : Node
        Represent final (destination) node of the problem
      Returns
      -------
        list
    """
    path = [target_node.value]
    node = target_node.parent
    while True:
      path.append(node.value)
      if node.parent is None:
        break
      node = node.parent
    return path


  def calculate_cost(self, path):
    """
      Calculate and return the total cost of the path
      ...
      Parameters
      ----------
        path : List
        Contains all the nodes of the path from the target node to the initial node
      Returns
      -------
        int
    """
    total_cost = 0
    for i in range(len(path) - 1):
      parent = self.graph.find_node(path[i])
      child = self.graph.find_node(path[i+1])

      for neighbor in child.neighbors:
        # Structure of neighbor(Node, weight)
        if neighbor[0] == parent:
          total_cost += neighbor[1]
    return total_cost
      

  def search(self):
    """
      Is the main algorithm. Search for a solution in the solution space of the problem
      Stops if the opened list is empty, so no solution found or if it find a solution. 
      ...
      Return
      ------
        list
    """
    # Calculate the heuristic value of the starting node
    # The distance from the starting node is 0 so only manhattan_distance is calculated
    self.start.distance_from_start = 0
    self.start.heuristic_value = self.manhattan_distance(self.start, self.target)
    # Add the starting point to opened list
    self.opened.append(self.start)

    while True:
      self.number_of_steps += 1

      if self.opened_is_empty():
        print(f"No Solution Found after {self.number_of_steps} steps!!!")
        break
        
      selected_node = self.remove_from_opened()
      # print(f"Selected Node {selected_node} has parent {selected_node.parent}")
      # check if the selected_node is the solution
      if selected_node == self.target:
        path = self.calculate_path(selected_node)
        total_cost = self.calculate_cost(path)
        path.reverse()

        return path, total_cost

      # extend the node
      new_nodes = selected_node.extend_node()

      # add the extended nodes in the list opened
      if len(new_nodes) > 0:
        for new_node in new_nodes:
          
          new_node.heuristic_value = self.calculate_heuristic_value(selected_node, new_node, self.target)
          if new_node not in self.closed and new_node not in self.opened:
            new_node.parent = selected_node
            self.insert_to_list("open", new_node)
          elif new_node in self.opened and new_node.parent != selected_node:
            old_node = self.get_old_node(new_node.value)
            if new_node.heuristic_value < old_node.heuristic_value:
              new_node.parent = selected_node
              self.insert_to_opened(new_node)

# def run(S,Z):
#     if S == Z:
#        print("error: ","You Can't type the same letter as the nodes for start and end")
#        return None
#     # Create graph
#     graph = Graph()
#     # Add vertices
#     graph.add_node(Node('A', (7,58)))
#     graph.add_node(Node('B', (34,58)))
#     graph.add_node(Node('C', (68,58)))
#     graph.add_node(Node('D', (7,50)))
#     graph.add_node(Node('E', (34,43)))
#     graph.add_node(Node('F', (60,41)))
#     graph.add_node(Node('G', (68,41)))
#     graph.add_node(Node('H', (25,26)))
#     graph.add_node(Node('I', (60,23)))
#     graph.add_node(Node('J', (60,2)))
    
#     # Add edges
#     graph.add_edge(1,'A', 'B',27)
#     graph.add_edge(1,'B', 'C',34)
#     graph.add_edge(3,'A', 'D',8)
#     graph.add_edge(2,'D', 'E',34)
#     graph.add_edge(3,'D', 'H',42)
#     graph.add_edge(2,'E', 'F',28)
#     graph.add_edge(2,'F', 'G',8)
#     graph.add_edge(3,'G', 'I',26)
#     graph.add_edge(3,'H', 'J',53)
#     graph.add_edge(2,'I', 'F',18)
#     graph.add_edge(3,'J', 'I',21)
#     graph.add_edge(3,'J', 'G',87)
#     graph.add_edge(3,'H', 'I',38)
#     graph.add_edge(2,'E', 'H',26)
#     graph.add_edge(1,'E', 'B',15)
#     graph.add_edge(3,'C', 'G',17)
   

#     # Execute the algorithm
#     alg = AStar(graph, S, Z)
#     path, path_length = alg.search()
#     print(" -> ".join(path))
#     print(f"Length of the path: {path_length}")
#     return (path,path_length)

# path = run('G','H')
# print(path)