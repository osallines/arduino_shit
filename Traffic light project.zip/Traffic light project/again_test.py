import socket

# Configuration
host = '127.0.0.1'  # Replace with your actual IP
port = 5555

# Create a socket object
peer_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the other peer
peer_socket.connect((host, port))
print(f"Connected to peer at {host}:{port}")

# Send data to the peer
input_data = "hahahlmao"  # Replace with your actual input
peer_socket.send(input_data.encode())

# Receive the response from the peer
response_data = peer_socket.recv(1024)  # Adjust buffer size as needed
print(f"Received response: {response_data.decode()}")

# Close the connection
peer_socket.close()